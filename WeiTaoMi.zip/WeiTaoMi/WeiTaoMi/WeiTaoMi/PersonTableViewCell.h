//
//  PersonTableViewCell.h
//  WeiTaoMi
//
//  Created by 微淘米 on 16/7/2.
//  Copyright © 2016年 微淘米. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *img;
@property (weak, nonatomic) IBOutlet UILabel *lb;

@end
