//
//  PersonTableViewCell.m
//  WeiTaoMi
//
//  Created by 微淘米 on 16/7/2.
//  Copyright © 2016年 微淘米. All rights reserved.
//

#import "PersonTableViewCell.h"

@implementation PersonTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
