//
//  MyCenterViewController.m
//  WeiTaoMi
//
//  Created by 微淘米 on 16/7/1.
//  Copyright © 2016年 微淘米. All rights reserved.
//

#import "MyCenterViewController.h"
#import "PersonTableViewCell.h"
#import "ImageViewController.h"
#import "CodeViewController.h"
#import "MyImageView.h"

@interface MyCenterViewController () <UITableViewDelegate,UITableViewDataSource,UINavigationControllerDelegate,UIImagePickerControllerDelegate> {
    
    UITableView *_tableView;
    
    NSArray *_ImgArray;
    
    NSArray *_array;
    
}

@end

@implementation MyCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initData];
    
    [self creatTableViewHeader];
    
    [self layoutTableView];
}

- (void)initData {
    
    self.navigationItem.title = @"个人中心";
    
    _array = @[@"任务通知",@"绑定手机",@"历史记录",@"邀请记录",@"提现记录",@"添加公众号",@"我的公众号",@"发布任务",@"任务管理"];
    
    _ImgArray = @[@"notes",@"iPhone",@"plan",@"invite",@"moneynotes"];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, W, H + 64 - 60)];
    
    [self.view addSubview:_tableView];
    
    _tableView.bounces = NO;
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake((W - 256)/2,H - 60 + 15,256, 30)];
    
    [self.view addSubview:btn];
    
    [btn setImage:[UIImage imageNamed:@"shop"] forState:UIControlStateNormal];
    
}

- (void)creatTableViewHeader {
    
    UIView *uv = [[UIView alloc] initWithFrame:CGRectMake(0, 0, W, 150)];
    
    // 个人中心头像
//    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake((W - 60) / 2, 10, 50, 50)];
//    [uv addSubview:btn];
//    [btn setImage:[UIImage imageNamed:@"headers"] forState:UIControlStateNormal];
//    [btn addTarget:self action:@selector(btnClickHeader:) forControlEvents:UIControlEventTouchUpInside];
    
    MyImageView *img = [MyImageView shearDBManager];
    img.frame = CGRectMake((W - 60) / 2, 10, 50, 50);
    [uv addSubview:img];
    
    
    img.image = [UIImage imageNamed:@"headers"];

    img.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(yourHandingCode:)];
    
    [img addGestureRecognizer:singleTap];
    
    // 显示用户名
    UILabel *lb = [[UILabel alloc] initWithFrame:CGRectMake((W - 60) / 2, 10 + 50 + 3, 60, 10)];
    [uv addSubview:lb];
    lb.text = @"微淘米";
    lb.textColor = [UIColor blackColor];
    
    //
    UILabel *lb_Num = [[UILabel alloc] initWithFrame:CGRectMake((W - 180)/2, 73 + 10 + 3, 180, 10)];
    [uv addSubview:lb_Num];
    lb_Num.text = @"29G2D9B37C";
    lb_Num.textColor = [UIColor lightGrayColor];
    lb_Num.textAlignment = NSTextAlignmentCenter;
    lb_Num.font = [UIFont systemFontOfSize:14];
    
    // 邀请码按钮
    UIButton *btn_Barcode = [[UIButton alloc] initWithFrame:CGRectMake((W - 256)/2, lb_Num.frame.origin.y + 10+ 20, 256, 30)];
    [uv addSubview:btn_Barcode];
    [btn_Barcode setImage:[UIImage imageNamed:@"yaoqingma"] forState:UIControlStateNormal];
    
    [btn_Barcode addTarget:self action:@selector(btnClickCode:) forControlEvents:UIControlEventTouchUpInside];
    
    _tableView.tableHeaderView = uv;
    
}


- (void)layoutTableView {
    
    _tableView.delegate = self;
    
    _tableView.dataSource = self;
    
    [_tableView registerNib:[UINib nibWithNibName:@"PersonTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    
    
}

//- (void)btnClickHeader:(UIButton *)btn {
//    
//    UIImagePickerController *imageIphone = [[UIImagePickerController alloc] init];
//    
//    // 设置资源类型
//    imageIphone.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
//    // 设置后是否可以后续操作
//    imageIphone.allowsEditing = YES;
//    imageIphone.delegate = self;
//
//    [self presentViewController:imageIphone animated:YES completion:nil];
//    
//}

- (void)yourHandingCode:(UIImageView *)img {
    
        UIImagePickerController *imageIphone = [[UIImagePickerController alloc] init];
    
        // 设置资源类型
        imageIphone.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        // 设置后是否可以后续操作
        imageIphone.allowsEditing = YES;
        imageIphone.delegate = self;
    
        [self presentViewController:imageIphone animated:YES completion:nil];
    
}

- (void)btnClickCode:(UIButton *)btn {
    
    CodeViewController *code = [[CodeViewController alloc] init];
    
    [self.navigationController pushViewController:code animated:YES];
}

#pragma mark - UITableView -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _ImgArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    PersonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    cell.img.image = [UIImage imageNamed:_ImgArray[indexPath.row]];
    
    cell.lb.text = _array[indexPath.row];
    
    return cell;
}



#pragma mark - UIImagePickerControllerDelegate -
// 点击choose完成按钮实现的方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    
    if ([type isEqualToString:@"public.image"]) {
        
        UIImage *imgs = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        
        UIImageWriteToSavedPhotosAlbum(imgs, nil, nil, nil);
        
        MyImageView *img = [MyImageView shearDBManager];
        img.image = imgs;
    }
    [picker dismissViewControllerAnimated:YES completion:^{
        
      
    }];
    
}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:^{
        
        
    }];

    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
