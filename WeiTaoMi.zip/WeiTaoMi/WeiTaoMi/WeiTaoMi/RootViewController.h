//
//  RootViewController.h
//  WeiTaoMi
//
//  Created by 微淘米 on 16/7/1.
//  Copyright © 2016年 微淘米. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@end
