//
//  CodeViewController.h
//  WeiTaoMi
//
//  Created by 微淘米 on 16/7/2.
//  Copyright © 2016年 微淘米. All rights reserved.
//

#import "RootViewController.h"

@interface CodeViewController : RootViewController

@end
