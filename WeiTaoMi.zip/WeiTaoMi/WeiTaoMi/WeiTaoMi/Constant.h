//
//  Constant.h
//  WeiTaoMi
//
//  Created by 微淘米 on 16/6/30.
//  Copyright © 2016年 微淘米. All rights reserved.
//

#import <Foundation/Foundation.h>

#define W self.view.frame.size.width
#define H self.view.frame.size.height

@interface Constant : NSObject

@end
