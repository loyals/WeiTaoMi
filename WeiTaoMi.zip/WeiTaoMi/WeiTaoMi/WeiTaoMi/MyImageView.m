//
//  MyImageView.m
//  WeiTaoMi
//
//  Created by 微淘米 on 16/7/2.
//  Copyright © 2016年 微淘米. All rights reserved.
//

#import "MyImageView.h"

@implementation MyImageView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

+ (MyImageView *)shearDBManager {
    
    static MyImageView *_instance = nil;
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken,^{
        
        _instance = [[super allocWithZone:NULL] init];
    });
    
    return _instance;
    
}

@end
