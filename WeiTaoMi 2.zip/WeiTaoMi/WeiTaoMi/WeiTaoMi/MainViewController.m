//
//  MainViewController.m
//  WeiTaoMi
//
//  Created by 微淘米 on 16/6/30.
//  Copyright © 2016年 微淘米. All rights reserved.
//

#import "MainViewController.h"
#import "MyCenterViewController.h"
#import "AttentionViewController.h"
#import "InviteViewController.h"
#import "DownloadViewController.h"
#import "MoneyViewController.h"
#import "NewViewController.h"
#import "HelpViewController.h"
#import "ReadViewController.h"

@interface MainViewController () {
    
    NSArray *_array;
    
    NSArray *_ImgArray;
    
    NSString *_str;
    
    
    
}

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initData];
   
    [self  creatUI];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    
    [self locationID];
}

- (void)locationID {
    
    
}


- (void)initData {
    
    _array = @[@"阅读文章",@"关注公众号",@"下载APP",@"邀请好友",@"钱包提现",@"新手奖励",@"帮助",@"添加栏目"];
    
    _ImgArray = @[@"read",@"attention",@"download",@"friend",@"money",@"new",@"help",@"add"];
    
    _str = @"未定位";
    
    _str_money = @"0.00";
    
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStyleBordered target:nil action:nil];
    
    [self.navigationItem setBackBarButtonItem:backItem];
    
}

- (void)creatUI {
    //  主视图的头视图
    UIView *uv = [[UIView alloc] initWithFrame:CGRectMake(0, 0, W, H / 4)];
    
    [self.view addSubview:uv];
    
    UIImageView *imgUV = [[UIImageView alloc] initWithFrame:uv.frame];
    
    imgUV.image = [UIImage imageNamed:@"headerImg"];
    
    [uv addSubview:imgUV];
    
    [self creatHeaderUV:uv];
    
    // 第二视图
    UIButton *btn_second = [[UIButton alloc] initWithFrame:CGRectMake(0, H/4, W, H/6)];
    
    [self.view addSubview:btn_second];
    
    [btn_second setImage:[UIImage imageNamed:@"banner"] forState:UIControlStateNormal];
    
    [btn_second addTarget:self action:@selector(btnClickElse:) forControlEvents:UIControlEventTouchUpInside];
    
    CGFloat w_btn = 60;
    
    CGFloat w_interval = (W - 60  *3) / 4;
    
    CGFloat h = H / 4 + H / 6;
    
    int s = 0;
    
    for (int i = 0; i < 3; i ++) {
        
        for (int j = 0; j < 3; j ++) {
            
            if (s == 8) {
                break;
            }else {
            
            UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(w_interval + j * (60 + w_btn), h + 20 + i * (w_interval + w_btn + 30), w_btn, w_btn)];
                
            UILabel *lb = [[UILabel alloc] initWithFrame:CGRectMake(btn.frame.origin.x - 20, btn.frame.origin.y  + 20  + 60, 100, 10)];
            
            
            [self.view addSubview:btn];
                
            [self.view addSubview:lb];
            
            [btn setImage:[UIImage imageNamed:_ImgArray[s]] forState:UIControlStateNormal];
                
            [btn  addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            
            btn.tag = 1000 + s;
                
            lb.text = _array[s];
                
            lb.textAlignment = NSTextAlignmentCenter;
            
            s++;
            }
        }
    }
}

- (void)creatHeaderUV:(UIView *)headerUV {
    
    CGFloat w = headerUV.frame.size.height;
    
    // 定位按钮
    UIImageView *img= [[UIImageView alloc] initWithFrame:CGRectMake(20, 20, 11, 18)];
    
    [headerUV addSubview:img];
    
    img.image = [UIImage imageNamed:@"coordinate"];
    
    UILabel *lb = [[UILabel alloc] initWithFrame:CGRectMake(15, 40, 21, 11)];
    
    [headerUV addSubview:lb];
    
    [lb setTextColor:[UIColor blackColor]];
    
    lb.text = _str;
    
    
    // 头像按钮
    UIButton *btn_heaerIMG = [[UIButton alloc] initWithFrame:CGRectMake(50, 40, 60, w/3)];
    
    [headerUV addSubview:btn_heaerIMG];
    
    [btn_heaerIMG setImage:[UIImage imageNamed:@"header"] forState:UIControlStateNormal];
    
    [btn_heaerIMG addTarget:self action:@selector(btnClickheaderIMG:) forControlEvents:UIControlEventTouchUpInside];
    
    // 现实余额的视图
    UILabel *lb_money = [[UILabel alloc] initWithFrame:CGRectMake(50, 120, 60, 30)];
    
    [headerUV addSubview:lb_money];
    
    lb_money.backgroundColor = [UIColor darkGrayColor];
    
    lb_money.text = [NSString stringWithFormat:@"%@ \n $ 我的钱包",_str_money];
    
    lb.adjustsFontSizeToFitWidth = YES;
    
    lb.textColor = [UIColor whiteColor];
    
    lb.layer.cornerRadius = 10;
    

    
}
- (BOOL)prefersStatusBarHidden {
    
    return YES;
}

- (void)btnClick:(UIButton *)btn {
    
    NSInteger i = btn.tag;
    
    ReadViewController *vc_read = [[ReadViewController alloc] init];
    
    AttentionViewController *vc_attention = [[AttentionViewController alloc] init];
    
    InviteViewController *vc_inviten = [[InviteViewController alloc] init];
    
    DownloadViewController *vc_download = [[DownloadViewController alloc] init];
    
    MoneyViewController *vc_money = [[MoneyViewController alloc] init];
    
    NewViewController *vc_new = [[ NewViewController alloc] init];
    
    HelpViewController *vc_help = [[HelpViewController alloc] init];
    
    
    switch (i) {
        case 1000:
            
            [self.navigationController pushViewController:vc_read animated:YES];
            
            
            break;
            
        case 1001:
            
            [self.navigationController pushViewController:vc_attention animated:YES];
            
            break;
            
        case 1002:
            
            [self.navigationController pushViewController:vc_download  animated:YES];
            
            break;
            
        case 1003:
            
            [self.navigationController pushViewController:vc_inviten  animated:YES];
            
            break;
            
        case 1004:
            
            [self.navigationController pushViewController:vc_money animated:YES];
            
            break;
            
        case 1005:
            
            [self.navigationController pushViewController:vc_new animated:YES];
            
            break;
            
        case 1006:
            
            [self.navigationController pushViewController:vc_help animated:YES];
            
            break;
            
        case 1007:
            
            [self.navigationController pushViewController:vc_help animated:YES];
            
            break;
            
        default:
            break;
    }
}


- (void)btnClickElse:(UIButton *)btn {
    
}


- (void)btnClickheaderIMG:(UIButton *)btn {
    
    MyCenterViewController *vc = [[MyCenterViewController alloc] init];
    
    [self.navigationController pushViewController:vc animated:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
